leatherman
==========

Useful functions when working in ROS.

This has both groovy(catkin) and Indigo versions.
